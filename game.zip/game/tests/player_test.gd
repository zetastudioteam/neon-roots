# GDScript placeholder
